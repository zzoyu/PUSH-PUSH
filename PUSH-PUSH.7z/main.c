﻿#include< stdio.h >
#include< conio.h >
#include< windows.h >

#include "initialize.h"
#include "gamefunction.h"

int main()
{
	Initialize();
	MainScreen();
	return 0;
}